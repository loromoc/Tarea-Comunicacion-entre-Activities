/*Romo Campos Luis Angel 5CV50*/
package com.example.aplicacioncomunicacionentreactivtys

import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {

    private lateinit var formLayout: ConstraintLayout
    private lateinit var mainLayout: ConstraintLayout
    private lateinit var editTextName: EditText
    private lateinit var editTextAge: EditText
    private lateinit var textViewName: TextView
    private lateinit var textViewAge: TextView
    private lateinit var submitButton: Button
    private lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        formLayout = findViewById(R.id.formLayout)
        mainLayout = findViewById(R.id.mainLayout)
        editTextAge = findViewById(R.id.editTextAge)
        editTextName = findViewById(R.id.editTextName)
        textViewAge = findViewById(R.id.textViewAge)
        textViewName = findViewById(R.id.textViewName)
        submitButton = findViewById(R.id.submitButton)
        backButton = findViewById(R.id.backButton)

        submitButton.setOnClickListener{
            val name = editTextName.text.toString()
            val age = editTextAge.text.toString()

            textViewName.text ="Nombre: $name"
            textViewAge.text ="Edad: $age"

            transitionLayouts(formLayout, mainLayout)
        }
        backButton.setOnClickListener{
            transitionLayouts(mainLayout, formLayout)
        }
    }

    private fun validateInputs(name: String, age: String): Boolean
    {
    if (name.isEmpty()|| age.isEmpty()){
        Toast.makeText(this,"Por favor Completa todos los campos", Toast.LENGTH_SHORT).show()
        return false
    }
        val ageInt = age.toIntOrNull()
        if (ageInt == null || ageInt <=0){
            Toast.makeText(this, "Por favor Ingresa una edad valida", Toast.LENGTH_SHORT).show()
            return false
        }
        return false
    }
    private fun transitionLayouts(hideView: View, showView: View){
        val fadeOut = AlphaAnimation(1.0f, 0.0f)
        fadeOut.duration = 500
        hideView.startAnimation(fadeOut)
        hideView.visibility = View.GONE

        val fadeIn = AlphaAnimation(0.0f, 1.0f)
        fadeIn.duration = 500
        showView.startAnimation(fadeIn)
        showView.visibility = View.VISIBLE
    }
}
